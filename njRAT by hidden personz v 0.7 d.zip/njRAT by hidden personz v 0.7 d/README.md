# RAT-NjRat-0.7d-modded-source-code
for educational purposes only

<br>
Modded :-

-Socket split key<br>
-Display Clients installed Anti-Virus<br>
-Updated GeoIP.dat<br>
-Anti // Sandboxie VMware Wireshark VirtualBox ProcessHacker ApateDNS ProcessExplorer <br>
-Spread USB<br>
-Obfuscation // Net Reactor<br>
-No-Ip Updater<br>
-Assembly Changer<br>


<img src="https://i.gyazo.com/f15a6f503a7b30675e2e796f9a18a1ca.png" width="450"/>

