﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Asemb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Asemb))
        Me.TXTFilename = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.T1 = New System.Windows.Forms.TextBox()
        Me.T2 = New System.Windows.Forms.TextBox()
        Me.T4 = New System.Windows.Forms.TextBox()
        Me.T3 = New System.Windows.Forms.TextBox()
        Me.T5 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.N1 = New System.Windows.Forms.NumericUpDown()
        Me.N2 = New System.Windows.Forms.NumericUpDown()
        Me.N3 = New System.Windows.Forms.NumericUpDown()
        Me.N4 = New System.Windows.Forms.NumericUpDown()
        Me.N9 = New System.Windows.Forms.NumericUpDown()
        Me.N8 = New System.Windows.Forms.NumericUpDown()
        Me.N7 = New System.Windows.Forms.NumericUpDown()
        Me.N6 = New System.Windows.Forms.NumericUpDown()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        CType(Me.N1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.N2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.N3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.N4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.N9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.N8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.N7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.N6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TXTFilename
        '
        Me.TXTFilename.BackColor = System.Drawing.SystemColors.InfoText
        Me.TXTFilename.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TXTFilename.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.TXTFilename.Location = New System.Drawing.Point(74, 9)
        Me.TXTFilename.Name = "TXTFilename"
        Me.TXTFilename.Size = New System.Drawing.Size(248, 26)
        Me.TXTFilename.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(2, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(65, 27)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Choose"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.UseVisualStyleBackColor = True
        '
        'T1
        '
        Me.T1.BackColor = System.Drawing.SystemColors.InfoText
        Me.T1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.T1.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.T1.Location = New System.Drawing.Point(74, 41)
        Me.T1.Name = "T1"
        Me.T1.Size = New System.Drawing.Size(248, 26)
        Me.T1.TabIndex = 2
        '
        'T2
        '
        Me.T2.BackColor = System.Drawing.SystemColors.InfoText
        Me.T2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.T2.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.T2.Location = New System.Drawing.Point(74, 73)
        Me.T2.Name = "T2"
        Me.T2.Size = New System.Drawing.Size(248, 26)
        Me.T2.TabIndex = 3
        '
        'T4
        '
        Me.T4.BackColor = System.Drawing.SystemColors.InfoText
        Me.T4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.T4.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.T4.Location = New System.Drawing.Point(74, 135)
        Me.T4.Name = "T4"
        Me.T4.Size = New System.Drawing.Size(248, 26)
        Me.T4.TabIndex = 5
        '
        'T3
        '
        Me.T3.BackColor = System.Drawing.SystemColors.InfoText
        Me.T3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.T3.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.T3.Location = New System.Drawing.Point(74, 103)
        Me.T3.Name = "T3"
        Me.T3.Size = New System.Drawing.Size(248, 26)
        Me.T3.TabIndex = 4
        '
        'T5
        '
        Me.T5.BackColor = System.Drawing.SystemColors.InfoText
        Me.T5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.T5.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.T5.Location = New System.Drawing.Point(74, 167)
        Me.T5.Name = "T5"
        Me.T5.Size = New System.Drawing.Size(248, 26)
        Me.T5.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 19)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Title"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(0, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 19)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Description"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(0, 105)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 19)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Company"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(0, 137)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 19)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Product"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(0, 169)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(90, 19)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Copyright"
        '
        'N1
        '
        Me.N1.BackColor = System.Drawing.SystemColors.InfoText
        Me.N1.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.N1.Location = New System.Drawing.Point(104, 203)
        Me.N1.Name = "N1"
        Me.N1.Size = New System.Drawing.Size(50, 26)
        Me.N1.TabIndex = 15
        '
        'N2
        '
        Me.N2.BackColor = System.Drawing.SystemColors.InfoText
        Me.N2.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.N2.Location = New System.Drawing.Point(160, 203)
        Me.N2.Name = "N2"
        Me.N2.Size = New System.Drawing.Size(50, 26)
        Me.N2.TabIndex = 16
        '
        'N3
        '
        Me.N3.BackColor = System.Drawing.SystemColors.InfoText
        Me.N3.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.N3.Location = New System.Drawing.Point(216, 202)
        Me.N3.Name = "N3"
        Me.N3.Size = New System.Drawing.Size(50, 26)
        Me.N3.TabIndex = 17
        '
        'N4
        '
        Me.N4.BackColor = System.Drawing.SystemColors.InfoText
        Me.N4.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.N4.Location = New System.Drawing.Point(272, 203)
        Me.N4.Name = "N4"
        Me.N4.Size = New System.Drawing.Size(50, 26)
        Me.N4.TabIndex = 18
        '
        'N9
        '
        Me.N9.BackColor = System.Drawing.SystemColors.InfoText
        Me.N9.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.N9.Location = New System.Drawing.Point(272, 237)
        Me.N9.Name = "N9"
        Me.N9.Size = New System.Drawing.Size(50, 26)
        Me.N9.TabIndex = 22
        '
        'N8
        '
        Me.N8.BackColor = System.Drawing.SystemColors.InfoText
        Me.N8.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.N8.Location = New System.Drawing.Point(216, 236)
        Me.N8.Name = "N8"
        Me.N8.Size = New System.Drawing.Size(50, 26)
        Me.N8.TabIndex = 21
        '
        'N7
        '
        Me.N7.BackColor = System.Drawing.SystemColors.InfoText
        Me.N7.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.N7.Location = New System.Drawing.Point(160, 237)
        Me.N7.Name = "N7"
        Me.N7.Size = New System.Drawing.Size(50, 26)
        Me.N7.TabIndex = 20
        '
        'N6
        '
        Me.N6.BackColor = System.Drawing.SystemColors.InfoText
        Me.N6.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.N6.Location = New System.Drawing.Point(104, 237)
        Me.N6.Name = "N6"
        Me.N6.Size = New System.Drawing.Size(50, 26)
        Me.N6.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(0, 210)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(117, 19)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "File Version"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(0, 243)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(144, 19)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Product Version"
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(190, 317)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(132, 22)
        Me.Button2.TabIndex = 25
        Me.Button2.Text = "Random Generator"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(190, 349)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(132, 22)
        Me.Button3.TabIndex = 26
        Me.Button3.Text = "Clone from (*exe)"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Location = New System.Drawing.Point(4, 317)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(132, 54)
        Me.Button4.TabIndex = 27
        Me.Button4.Text = "Change And Save"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Location = New System.Drawing.Point(2, 272)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(65, 27)
        Me.Button6.TabIndex = 29
        Me.Button6.Text = "Icon"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.TextBox1.Location = New System.Drawing.Point(74, 274)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(248, 26)
        Me.TextBox1.TabIndex = 31
        '
        'Asemb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(326, 375)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.N9)
        Me.Controls.Add(Me.N8)
        Me.Controls.Add(Me.N7)
        Me.Controls.Add(Me.N6)
        Me.Controls.Add(Me.N4)
        Me.Controls.Add(Me.N3)
        Me.Controls.Add(Me.N2)
        Me.Controls.Add(Me.N1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.T5)
        Me.Controls.Add(Me.T4)
        Me.Controls.Add(Me.T3)
        Me.Controls.Add(Me.T2)
        Me.Controls.Add(Me.T1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TXTFilename)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Asemb"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Assembly Cloner"
        CType(Me.N1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.N2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.N3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.N4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.N9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.N8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.N7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.N6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TXTFilename As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents T1 As System.Windows.Forms.TextBox
    Friend WithEvents T2 As System.Windows.Forms.TextBox
    Friend WithEvents T4 As System.Windows.Forms.TextBox
    Friend WithEvents T3 As System.Windows.Forms.TextBox
    Friend WithEvents T5 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents N1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents N2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents N3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents N4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents N9 As System.Windows.Forms.NumericUpDown
    Friend WithEvents N8 As System.Windows.Forms.NumericUpDown
    Friend WithEvents N7 As System.Windows.Forms.NumericUpDown
    Friend WithEvents N6 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button6 As Button
    Friend WithEvents TextBox1 As TextBox
End Class
