﻿Imports System

Namespace j
    Public Class A
        ' Methods
        <STAThread>
        Public Shared Sub main()
            OK.ko()

        End Sub

    End Class
End Namespace

